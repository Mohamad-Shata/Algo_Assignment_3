#include <bits/stdc++.h>
using namespace std;

int main() {
    string greedString,SizeString;
    getline(cin,greedString);
    getline(cin,SizeString);

    vector<int> g;
    stringstream ss(greedString);
    int num1;
    while(ss>>num1) {
        g.push_back(num1);
    }
    vector<int> s;
    stringstream ss2(SizeString);
    int num2;
    while(ss2>>num2) {
        s.push_back(num2);
    }

    sort(g.begin(),g.end());
    sort(s.begin(),s.end());

    int i,j = 0;
    while(i < g.size() && j < s.size()) {
        if(s[j]>=g[i]) {
            i++;
        }
            j++;
    }

    cout<<i<<endl;
    return 0;
}

#include <bits/stdc++.h>
using namespace std;

int main() {
    vector<char> tasks;
    char task;
    int n;
    while(true) {
        cin>>task;
        if(task == '0') {break;}
        if(isupper(task)) {tasks.push_back(task);}
    }
    cin>>n;
    map<char,int>tasksFreq;
    for(char& task : tasks) {
        tasksFreq[task]++;
    }

    int maxfreq = 0;
    int maxcount = 0;
    for(auto [task , count]: tasksFreq) {
        if(count > maxfreq) {
            maxfreq = count;
             maxcount = 1;
        }else if(count == maxfreq) {maxcount++;}
    }

    int gaps =(maxfreq -1)*(n+1)+maxcount;
    int result = max((int)tasks.size(),gaps);
    cout<<result<<endl;
    return 0;
}

#include <iostream>
#include <unordered_map>
#include <set>
using namespace std;

bool DFS(int node, int destination, unordered_map<int, vector<int>>& graph, set<int>& visited) {
    if (node == destination)
        return true;

    visited.insert(node); // Mark the node as visited

    // Explore all adjacent nodes (neighbors)
    for (int vertex : graph[node]) {
        // If the neighbor has not been visited, perform DFS on it
        if (visited.find(vertex) == visited.end()) {
            if (DFS(vertex, destination, graph, visited))
                return true;
        }
    }
    return false;
}

bool validPath(int n, vector<vector<int>>& edges, int source, int destination) {
    if (source == destination)
        return true;

    // Step 1: Build the graph as an adjacency list using unordered_map
    unordered_map<int, vector<int>> graph;
    for (auto edge : edges) {
        graph[edge[0]].push_back(edge[1]);
        graph[edge[1]].push_back(edge[0]);
    }

    // Step 2: Initialize a set to keep track of visited nodes
    set<int> visited;
    return DFS(source, destination, graph, visited);
}

int main() {
    vector<vector<int>> edge={{0,1},{1,2},{2,0}};
    cout<< validPath(3,edge,0,2);

}

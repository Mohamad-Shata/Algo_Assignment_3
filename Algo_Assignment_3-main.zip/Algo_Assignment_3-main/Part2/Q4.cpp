#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <climits>

using namespace std;

// Disjoint Set Union (DSU)
class DSU {
    vector<int> parent, rank;

public:
    DSU(int n) {
        parent.resize(n + 1, -1);
        rank.resize(n + 1, 1);
    }

    // Find function with path compression
    int find(int i) {
        if (parent[i] == -1) return i;
        return parent[i] = find(parent[i]);
    }

    // Union function by rank
    void unite(int x, int y) {
        int s1 = find(x);
        int s2 = find(y);

        if (s1 != s2) {
            if (rank[s1] < rank[s2]) {
                parent[s1] = s2;
            } else if (rank[s1] > rank[s2]) {
                parent[s2] = s1;
            } else {
                parent[s2] = s1;
                rank[s1]++;
            }
        }
    }
};

// Main function
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);


    int n, m, g, s;
    cin >> n >> m >> g >> s; // cities, roads, gold coin, silver coin

    vector<vector<int>> edgeList; // {gold, silver, city1, city2}
    set<int> uniqueG; // To store unique gold costs

    for (int i = 0; i < m; i++) {
        int city1, city2, gold, silver;
        cin >> city1 >> city2 >> gold >> silver;
        edgeList.push_back({gold, silver, city1, city2});
        uniqueG.insert(gold);
    }

    // Sort edges by gold cost first
    sort(edgeList.begin(), edgeList.end());

    long long minCost = LLONG_MAX;

    // Iterate over each unique gi
    vector<vector<int>> subgraph;
    for (auto& edge: edgeList) {
        // Filter edges where gi <= current_gi
        subgraph.emplace_back(edge);
        // Sort the subgraph edges by silver cost
        sort(subgraph.begin(), subgraph.end(), [](const vector<int> &a, const vector<int> &b) {
            return a[1] < b[1]; // Sort by silver
        });

        DSU dsu(n);
        int edgesUsed = 0;
        int maxS = -1;

        for (auto &edge : subgraph) {
            int gold = edge[0];
            int silver = edge[1];
            int city1 = edge[2];
            int city2 = edge[3];

            if (dsu.find(city1) != dsu.find(city2)) {
                dsu.unite(city1, city2);
                edgesUsed++;
                maxS = max(maxS, silver); // Track the max silver cost in MST
            }
        }

        // Check if MST spans all cities
        if (edgesUsed == n - 1) {
            long long cost = (1LL * g * edge[0]) + (1LL * s * maxS); // Use long long for calculation
            minCost = min(minCost, cost);
        }
    }

    if (minCost == LLONG_MAX) {
        cout << -1; // No MST found
    } else {
        cout << minCost; // Print the minimum cost
    }

    return 0;
}
#include <iostream>
#include <vector>
#include <map>
#include <unordered_map>
#include <algorithm>
#include <cmath>
#include <set>
#include <bitset>

using namespace std;

// Disjoint Set Union (DSU)
class DSU {
    vector<int> parent, rank;

public:
    DSU(int n) {
        parent.resize(n + 1, -1);
        rank.resize(n + 1, 1);
    }

    // Find function with path compression
    int find(int i) {
        if (parent[i] == -1) return i;
        return parent[i] = find(parent[i]);
    }

    // Union function by rank
    void unite(int x, int y) {
        int s1 = find(x);
        int s2 = find(y);

        if (s1 != s2) {
            if (rank[s1] < rank[s2]) {
                parent[s1] = s2;
            } else if (rank[s1] > rank[s2]) {
                parent[s2] = s1;
            } else {
                parent[s2] = s1;
                rank[s1]++;
            }
        }
    }
};



int DFS(int node, map<int, vector<pair<int, int>>>& graph, set<int>& visited, vector<long long>&freq,int n) {
    //cout<<"HRE";
    visited.insert(node); // Mark the node as visited
    int c=1;
    for (auto vertex : graph[node]) {
        if (visited.find(vertex.first) == visited.end()) {
            int c2=DFS(vertex.first, graph, visited, freq,n);
            c += c2;
            freq[vertex.second] += (long long)c2 * (n - c2);
        }
    }
    return c;
}


void freqToBin(vector<long long>&freq){
    for(int i=0;i<freq.size();i++){
        int half = freq[i]/2;
        freq[i]=freq[i]%2; //remainder

        if(i==freq.size()-1){
            if(half==0)break;
            else freq.push_back(half);
            continue;
        }
        freq[i+1]= freq[i+1]+half;
    }
}
// Main function
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;
    cin >> n >> m; // cities, edges

    vector<vector<int>> edgeList; // {weight, city1, city2}
    set<int> cities;
    for (int i = 0; i < m; i++) {
        int city1, city2, weight;
        cin >> city1 >> city2 >> weight;
        edgeList.push_back({weight, city1, city2});
    }

    // Sort edges by weight
    sort(edgeList.begin(), edgeList.end());

    DSU dsu(n);
    vector<vector<int>> usedMST; // Edges used in the MST
    int maxW=-1;// to intialize the frequency vector with a size.
    for (auto &tempEdge : edgeList) {
        int weight = tempEdge[0];
        int city1 = tempEdge[1];
        int city2 = tempEdge[2];
        if (dsu.find(city1) != dsu.find(city2)) {
            dsu.unite(city1, city2);
            usedMST.push_back({weight, city1, city2});
            maxW =max(maxW,weight);
        }
    }


    //creating the required graph for DFS
    map<int, vector<pair<int, int>>> adjList;
    for (auto edge : usedMST) {
        int city1 = edge[1];
        int city2 = edge[2];
        adjList[city1].push_back({city2, edge[0]});
        adjList[city2].push_back({city1, edge[0]});
    }


    set<int> visited;
    vector<long long> freq(maxW + 1);//frequency of each weight

    int startNode = 1;
    DFS(startNode, adjList, visited, freq,n);


    freqToBin(freq);
    int size=freq.size()-1;
    while(size >= 0 && freq[size]==0){
        freq.pop_back();
        size--;
    }
    for(int i= size;i>=0;i--)
        cout<<freq[i];

    return 0;

//    00011110
//    01111000
}